<?php
require_once 'config.php';
if (!isset($_SESSION['user_id']) || $_SESSION['is_admin']) {
    header('Location: index.php');
    exit;
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $course_name = trim($_POST['course_name'] ?? '');
    $start_date = $_POST['start_date'] ?? '';
    $payment_method = $_POST['payment_method'] ?? '';

    $errors = [];
    if (empty($course_name)) $errors[] = "Введите название курса.";
    if (empty($start_date)) $errors[] = "Выберите дату начала.";
    if (!in_array($payment_method, ['cash', 'phone_transfer'])) $errors[] = "Выберите способ оплаты.";

    if (empty($errors)) {
        $stmt = $pdo->prepare("INSERT INTO applications (user_id, course_name, start_date, payment_method) VALUES (?, ?, ?, ?)");
        $stmt->execute([$_SESSION['user_id'], $course_name, $start_date, $payment_method]);
        header('Location: user_dashboard.php?success=1');
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Новая заявка</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h2>Формирование заявки</h2>
        <?php if (!empty($errors)): ?>
            <?php foreach ($errors as $e): ?>
                <div class="error"><?php echo $e; ?></div>
            <?php endforeach; ?>
        <?php endif; ?>
        <form method="POST">
            <label>Наименование курса</label>
            <input type="text" name="course_name" required>
            
            <label>Желаемая дата начала обучения</label>
            <input type="date" name="start_date" required>
            
            <label>Способ оплаты</label>
            <select name="payment_method" required>
                <option value="">-- Выберите --</option>
                <option value="cash">Наличными</option>
                <option value="phone_transfer">Перевод по номеру телефона</option>
            </select>
            
            <button type="submit">Отправить</button>
        </form>
        <div class="link"><a href="user_dashboard.php">← Назад в кабинет</a></div>
    </div>
</body>
</html>

<header class="header">
    <div class="header-inner">
        <a href="index.php" class="logo">Корочки<span>.есть</span></a>
        <nav class="nav-links">
            <a href="index.php">Курсы</a>
            <a href="user_dashboard.php">Мои заявки</a>
            <a href="logout.php" class="btn-outline">Выйти</a>
        </nav>
    </div>
</header>