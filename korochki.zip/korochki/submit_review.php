<?php
require_once 'config.php';
if (!isset($_SESSION['user_id']) || $_SESSION['is_admin']) {
    header('Location: index.php');
    exit;
}
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['review_message'])) {
    $message = trim($_POST['review_message']);
    $stmt = $pdo->prepare("INSERT INTO reviews (user_id, message) VALUES (?, ?)");
    $stmt->execute([$_SESSION['user_id'], $message]);
}
header('Location: user_dashboard.php');
exit;
?>