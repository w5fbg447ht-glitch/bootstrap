<?php require_once 'config.php'; ?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Корочки.есть – Онлайн-курсы ДПО</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <!-- Шапка -->
    <header class="header">
        <a href="index.php" class="logo">Корочки<span>.есть</span></a>
        <nav class="nav-links">
            <?php if (isset($_SESSION['user_id']) && !$_SESSION['is_admin']): ?>
                <span class="user-name">👤 Пользователь</span>
                <a href="user_dashboard.php">Мои заявки</a>
                <a href="create_app.php" class="btn-primary">Создать заявку</a>
                <a href="logout.php" class="btn-outline">Выйти</a>
            <?php elseif (isset($_SESSION['is_admin']) && $_SESSION['is_admin']): ?>
                <span class="user-name">🛡️ Администратор</span>
                <a href="admin.php">Панель управления</a>
                <a href="logout.php" class="btn-outline">Выйти</a>
            <?php else: ?>
                <a href="login.php">Вход</a>
                <a href="register.php" class="btn-primary">Регистрация</a>
            <?php endif; ?>
        </nav>
    </header>

    <!-- Основной контент -->
    <main class="main-container">
        <!-- Баннер -->
        <section class="banner">
            <h1>📚 Дополнительное профессиональное образование</h1>
            <p>Повышайте квалификацию с лучшими преподавателями. Дипломы и сертификаты установленного образца.</p>
        </section>

        <!-- Карточки курсов -->
        <section class="courses-grid">
            <!-- Курс 1 -->
            <div class="course-card">
                <div class="course-icon">💻</div>
                <h3>Веб-разработка на PHP и MySQL</h3>
                <p>Полный курс по созданию динамических сайтов и веб-приложений с нуля. Изучите backend-разработку.</p>
                <div class="course-meta">
                    <span>⏱ 72 часа</span>
                    <span>📅 Старт: каждый месяц</span>
                </div>
                <?php if (isset($_SESSION['user_id']) && !$_SESSION['is_admin']): ?>
                    <a href="create_app.php?course=Веб-разработка+на+PHP+и+MySQL" class="btn btn-primary btn-full">Записаться на курс</a>
                <?php elseif (!isset($_SESSION['user_id'])): ?>
                    <a href="login.php" class="btn btn-primary btn-full">Войдите, чтобы записаться</a>
                <?php endif; ?>
            </div>

            <!-- Курс 2 -->
            <div class="course-card">
                <div class="course-icon">📊</div>
                <h3>Анализ данных и Python</h3>
                <p>Освойте Pandas, NumPy и визуализацию данных. Научитесь принимать решения на основе данных.</p>
                <div class="course-meta">
                    <span>⏱ 48 часов</span>
                    <span>📅 Старт: 15 июля</span>
                </div>
                <?php if (isset($_SESSION['user_id']) && !$_SESSION['is_admin']): ?>
                    <a href="create_app.php?course=Анализ+данных+и+Python" class="btn btn-primary btn-full">Записаться на курс</a>
                <?php elseif (!isset($_SESSION['user_id'])): ?>
                    <a href="login.php" class="btn btn-primary btn-full">Войдите, чтобы записаться</a>
                <?php endif; ?>
            </div>

            <!-- Курс 3 -->
            <div class="course-card">
                <div class="course-icon">🎨</div>
                <h3>UX/UI Дизайн</h3>
                <p>Проектирование пользовательских интерфейсов. Figma, прототипирование, юзабилити-тестирование.</p>
                <div class="course-meta">
                    <span>⏱ 60 часов</span>
                    <span>📅 Старт: 1 августа</span>
                </div>
                <?php if (isset($_SESSION['user_id']) && !$_SESSION['is_admin']): ?>
                    <a href="create_app.php?course=UX/UI+Дизайн" class="btn btn-primary btn-full">Записаться на курс</a>
                <?php elseif (!isset($_SESSION['user_id'])): ?>
                    <a href="login.php" class="btn btn-primary btn-full">Войдите, чтобы записаться</a>
                <?php endif; ?>
            </div>

            <!-- Курс 4 -->
            <div class="course-card">
                <div class="course-icon">📱</div>
                <h3>Мобильная разработка на Flutter</h3>
                <p>Кроссплатформенная разработка приложений для iOS и Android на языке Dart.</p>
                <div class="course-meta">
                    <span>⏱ 80 часов</span>
                    <span>📅 Старт: 20 июня</span>
                </div>
                <?php if (isset($_SESSION['user_id']) && !$_SESSION['is_admin']): ?>
                    <a href="create_app.php?course=Мобильная+разработка+на+Flutter" class="btn btn-primary btn-full">Записаться на курс</a>
                <?php elseif (!isset($_SESSION['user_id'])): ?>
                    <a href="login.php" class="btn btn-primary btn-full">Войдите, чтобы записаться</a>
                <?php endif; ?>
            </div>

            <!-- Курс 5 -->
            <div class="course-card">
                <div class="course-icon">🔒</div>
                <h3>Кибербезопасность</h3>
                <p>Защита информации, этичный хакинг, сетевая безопасность. Практические кейсы.</p>
                <div class="course-meta">
                    <span>⏱ 90 часов</span>
                    <span>📅 Старт: 10 сентября</span>
                </div>
                <?php if (isset($_SESSION['user_id']) && !$_SESSION['is_admin']): ?>
                    <a href="create_app.php?course=Кибербезопасность" class="btn btn-primary btn-full">Записаться на курс</a>
                <?php elseif (!isset($_SESSION['user_id'])): ?>
                    <a href="login.php" class="btn btn-primary btn-full">Войдите, чтобы записаться</a>
                <?php endif; ?>
            </div>

            <!-- Курс 6 -->
            <div class="course-card">
                <div class="course-icon">📈</div>
                <h3>Интернет-маркетинг</h3>
                <p>SEO, SMM, контекстная реклама, email-маркетинг. Продвижение бренда в digital-среде.</p>
                <div class="course-meta">
                    <span>⏱ 54 часа</span>
                    <span>📅 Старт: 5 июля</span>
                </div>
                <?php if (isset($_SESSION['user_id']) && !$_SESSION['is_admin']): ?>
                    <a href="create_app.php?course=Интернет-маркетинг" class="btn btn-primary btn-full">Записаться на курс</a>
                <?php elseif (!isset($_SESSION['user_id'])): ?>
                    <a href="login.php" class="btn btn-primary btn-full">Войдите, чтобы записаться</a>
                <?php endif; ?>
            </div>
        </section>
    </main>
</body>
</html>