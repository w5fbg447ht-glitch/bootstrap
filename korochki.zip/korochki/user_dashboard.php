<?php
require_once 'config.php';
if (!isset($_SESSION['user_id']) || $_SESSION['is_admin']) {
    header('Location: login.php');
    exit;
}
$user_id = $_SESSION['user_id'];
$user_stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$user_stmt->execute([$user_id]);
$user = $user_stmt->fetch();

$apps_stmt = $pdo->prepare("SELECT * FROM applications WHERE user_id = ? ORDER BY created_at DESC");
$apps_stmt->execute([$user_id]);
$applications = $apps_stmt->fetchAll();

$reviews_stmt = $pdo->prepare("SELECT * FROM reviews WHERE user_id = ? ORDER BY created_at DESC");
$reviews_stmt->execute([$user_id]);
$reviews = $reviews_stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Личный кабинет – Корочки.есть</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header class="header">
        <a href="index.php" class="logo">Корочки<span>.есть</span></a>
        <nav class="nav-links">
            <a href="index.php">Курсы</a>
            <a href="create_app.php" class="btn-primary">Новая заявка</a>
            <a href="logout.php" class="btn-outline">Выйти</a>
        </nav>
    </header>

    <main class="main-container" style="max-width: 900px;">
        <h2 style="margin-bottom: 25px;">👤 Добро пожаловать, <?php echo htmlspecialchars($user['full_name']); ?>!</h2>

        <h3>📋 Ваши заявки на обучение</h3>
        <?php if (count($applications) > 0): ?>
        <table style="margin-bottom: 40px;">
            <tr><th>Курс</th><th>Дата начала</th><th>Оплата</th><th>Статус</th></tr>
            <?php foreach ($applications as $app): 
                $status_class = 'status-' . $app['status'];
                $status_text = ['new' => 'Новая', 'in_progress' => 'Идет обучение', 'completed' => 'Завершено'][$app['status']];
            ?>
            <tr>
                <td><?php echo htmlspecialchars($app['course_name']); ?></td>
                <td><?php echo $app['start_date']; ?></td>
                <td><?php echo $app['payment_method'] == 'cash' ? 'Наличные' : 'Перевод'; ?></td>
                <td><span class="status-badge <?php echo $status_class; ?>"><?php echo $status_text; ?></span></td>
            </tr>
            <?php endforeach; ?>
        </table>
        <?php else: ?>
            <p style="margin-bottom: 40px;">У вас пока нет заявок. <a href="index.php">Выбрать курс</a></p>
        <?php endif; ?>

        <h3>💬 Оставить отзыв</h3>
        <form action="submit_review.php" method="POST" style="margin-bottom: 30px;">
            <textarea name="review_message" rows="4" placeholder="Поделитесь впечатлениями о качестве обучения..." required></textarea>
            <button type="submit" class="btn btn-primary btn-full">Отправить отзыв</button>
        </form>

        <h3>📝 Ваши отзывы</h3>
        <?php if (count($reviews) > 0): ?>
            <?php foreach ($reviews as $review): ?>
                <div class="review-block">
                    <small><?php echo $review['created_at']; ?></small>
                    <p><?php echo htmlspecialchars($review['message']); ?></p>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <p>Вы еще не оставляли отзывов.</p>
        <?php endif; ?>
    </main>
</body>
</html>

<header class="header">
    <div class="header-inner">
        <a href="index.php" class="logo">Корочки<span>.есть</span></a>
        <nav class="nav-links">
            <a href="index.php">Курсы</a>
            <a href="create_app.php" class="btn-primary">Новая заявка</a>
            <a href="logout.php" class="btn-outline">Выйти</a>
        </nav>
    </div>
</header>