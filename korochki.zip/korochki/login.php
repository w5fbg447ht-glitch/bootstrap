<?php require_once 'config.php'; ?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Вход – Корочки.есть</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header class="header">
        <a href="index.php" class="logo">Корочки<span>.есть</span></a>
        <nav class="nav-links">
            <a href="index.php">Главная</a>
            <a href="register.php">Регистрация</a>
        </nav>
    </header>

    <div class="form-container">
        <h2>🔐 Вход в систему</h2>
        <?php
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $login = trim($_POST['login'] ?? '');
            $password = trim($_POST['password'] ?? '');

            // Проверка администратора
            if ($login === 'Admin' && $password === 'KorokNET') {
                $_SESSION['user_id'] = 0;
                $_SESSION['is_admin'] = true;
                header('Location: admin.php');
                exit;
            }

            // Проверка обычного пользователя
            $stmt = $pdo->prepare("SELECT * FROM users WHERE login = ?");
            $stmt->execute([$login]);
            $user = $stmt->fetch();

            if ($user && password_verify($password, $user['password'])) {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['is_admin'] = false;
                header('Location: index.php');
                exit;
            } else {
                echo '<div class="error">❌ Неверный логин или пароль.</div>';
            }
        }
        ?>
        <form method="POST">
            <label>Логин</label>
            <input type="text" name="login" placeholder="Введите логин" required>
            
            <label>Пароль</label>
            <input type="password" name="password" placeholder="Введите пароль" required>
            
            <button type="submit" class="btn btn-primary btn-full">Войти</button>
        </form>
        <div class="link">
            <a href="register.php">Еще не зарегистрированы? Регистрация</a>
        </div>
    </div>
</body>
</html>

<header class="header">
    <div class="header-inner">
        <a href="index.php" class="logo">Корочки<span>.есть</span></a>
        <nav class="nav-links">
            <a href="index.php">Главная</a>
            <a href="register.php">Регистрация</a>
        </nav>
    </div>
</header>