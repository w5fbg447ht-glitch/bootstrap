<?php
require_once 'config.php';
if (!isset($_SESSION['is_admin']) || $_SESSION['is_admin'] !== true) {
    header('Location: login.php');
    exit;
}
$stmt = $pdo->query("SELECT a.*, u.full_name, u.email FROM applications a JOIN users u ON a.user_id = u.id ORDER BY a.created_at DESC");
$applications = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Панель администратора – Корочки.есть</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header class="header">
        <a href="index.php" class="logo">Корочки<span>.есть</span></a>
        <nav class="nav-links">
            <span class="user-name">🛡️ Администратор</span>
            <a href="index.php">На сайт</a>
            <a href="logout.php" class="btn-outline">Выйти</a>
        </nav>
    </header>

    <main class="main-container" style="max-width: 1200px;">
        <h2 style="margin-bottom: 25px;">⚙️ Управление заявками</h2>
        
        <?php if (count($applications) > 0): ?>
        <table>
            <tr>
                <th>ID</th><th>Пользователь</th><th>Курс</th><th>Дата начала</th><th>Оплата</th><th>Статус</th><th>Действие</th>
            </tr>
            <?php foreach ($applications as $app): 
                $status_class = 'status-' . $app['status'];
                $status_text = ['new' => 'Новая', 'in_progress' => 'Идет обучение', 'completed' => 'Завершено'][$app['status']];
            ?>
            <tr>
                <td>#<?php echo $app['id']; ?></td>
                <td>
                    <strong><?php echo htmlspecialchars($app['full_name']); ?></strong><br>
                    <small><?php echo $app['email']; ?></small>
                </td>
                <td><?php echo htmlspecialchars($app['course_name']); ?></td>
                <td><?php echo date('d.m.Y', strtotime($app['start_date'])); ?></td>
                <td><?php echo $app['payment_method'] == 'cash' ? 'Наличные' : 'Перевод'; ?></td>
                <td><span class="status-badge <?php echo $status_class; ?>"><?php echo $status_text; ?></span></td>
                <td>
                    <form action="update_status.php" method="POST" style="display:flex; gap:5px;">
                        <input type="hidden" name="app_id" value="<?php echo $app['id']; ?>">
                        <select name="new_status" style="margin-bottom: 0;">
                            <option value="new" <?php echo $app['status'] == 'new' ? 'selected' : ''; ?>>Новая</option>
                            <option value="in_progress" <?php echo $app['status'] == 'in_progress' ? 'selected' : ''; ?>>Идет обучение</option>
                            <option value="completed" <?php echo $app['status'] == 'completed' ? 'selected' : ''; ?>>Завершено</option>
                        </select>
                        <button type="submit" class="btn btn-success" style="padding:8px 15px; white-space: nowrap;">✓ Применить</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; ?>
        </table>
        <?php else: ?>
            <p>Заявок пока нет.</p>
        <?php endif; ?>
    </main>
</body>
</html>

<header class="header">
    <div class="header-inner">
        <a href="index.php" class="logo">Корочки<span>.есть</span></a>
        <nav class="nav-links">
            <span class="user-name">🛡️ Администратор</span>
            <a href="index.php">На сайт</a>
            <a href="logout.php" class="btn-outline">Выйти</a>
        </nav>
    </div>
</header>