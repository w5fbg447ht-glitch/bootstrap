<?php require_once 'config.php'; ?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Регистрация – Корочки.есть</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header class="header">
        <a href="index.php" class="logo">Корочки<span>.есть</span></a>
        <nav class="nav-links">
            <a href="index.php">Главная</a>
            <a href="login.php">Вход</a>
        </nav>
    </header>

    <div class="form-container">
        <h2>📝 Регистрация</h2>
        <?php
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $login = trim($_POST['login'] ?? '');
            $password = $_POST['password'] ?? '';
            $full_name = trim($_POST['full_name'] ?? '');
            $phone = trim($_POST['phone'] ?? '');
            $email = trim($_POST['email'] ?? '');

            $errors = [];

            if (!preg_match('/^[a-zA-Z0-9]{6,}$/', $login)) {
                $errors[] = "Логин должен содержать только латиницу и цифры, не менее 6 символов.";
            }
            if (strlen($password) < 8) {
                $errors[] = "Пароль должен быть не менее 8 символов.";
            }
            if (!preg_match('/^[а-яё\s]+$/iu', $full_name)) {
                $errors[] = "ФИО должно содержать только кириллицу и пробелы.";
            }
            if (!preg_match('/^8\(\d{3}\)\d{3}-\d{2}-\d{2}$/', $phone)) {
                $errors[] = "Телефон должен быть в формате 8(XXX)XXX-XX-XX.";
            }
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $errors[] = "Некорректный email.";
            }

            $stmt = $pdo->prepare("SELECT id FROM users WHERE login = ?");
            $stmt->execute([$login]);
            if ($stmt->fetch()) {
                $errors[] = "Пользователь с таким логином уже существует.";
            }

            if (empty($errors)) {
                $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                $stmt = $pdo->prepare("INSERT INTO users (login, password, full_name, phone, email) VALUES (?, ?, ?, ?, ?)");
                if ($stmt->execute([$login, $hashed_password, $full_name, $phone, $email])) {
                    echo '<div class="success">✅ Регистрация успешна! <a href="login.php">Войти</a></div>';
                } else {
                    echo '<div class="error">Ошибка регистрации.</div>';
                }
            } else {
                foreach ($errors as $error) {
                    echo '<div class="error">' . htmlspecialchars($error) . '</div>';
                }
            }
        }
        ?>
        <form method="POST">
            <label>Логин (лат. и цифры, мин. 6)</label>
            <input type="text" name="login" placeholder="user123" required>
            
            <label>Пароль (мин. 8 символов)</label>
            <input type="password" name="password" placeholder="Не менее 8 символов" required>
            
            <label>ФИО (кириллица)</label>
            <input type="text" name="full_name" placeholder="Иванов Иван Иванович" required>
            
            <label>Телефон (8(XXX)XXX-XX-XX)</label>
            <input type="text" name="phone" placeholder="8(999)123-45-67" required>
            
            <label>Email</label>
            <input type="email" name="email" placeholder="example@mail.ru" required>
            
            <button type="submit" class="btn btn-primary btn-full">Создать пользователя</button>
        </form>
        <div class="link">
            <a href="login.php">Уже зарегистрированы? Войти</a>
        </div>
    </div>
</body>
</html>

<header class="header">
    <div class="header-inner">
        <a href="index.php" class="logo">Корочки<span>.есть</span></a>
        <nav class="nav-links">
            <a href="index.php">Главная</a>
            <a href="login.php">Вход</a>
        </nav>
    </div>
</header>